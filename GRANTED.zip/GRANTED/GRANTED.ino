
/*
  Arduino Nano + DRV8833 + KY-037

  声音触发 -> 执行路线 -> 停止 -> 再次等待声音

  运动过程中完全忽略声音。
  路线结束后自动重新进入待机状态。
  不需要按 RESET。
*/

// ====================================
// 1. 选择表演路线
// ====================================

// 1 = 第一次表演
// 2 = 第二次表演
// 3 = 第三次表演

const int ROUTE_NUMBER = 1;


// ====================================
// 2. Arduino Nano 接线
// ====================================

const int L1 = 5;     // DRV8833 IN1
const int L2 = 6;     // DRV8833 IN2

const int R1 = 9;     // DRV8833 IN3
const int R2 = 10;    // DRV8833 IN4

const int MIC = A0;   // KY-037 AO


// ====================================
// 3. 校准参数
// ====================================

// 直行速度
const int DRIVE_PWM = 180;

// 转向速度
const int TURN_PWM = 190;

// 前进1厘米所需毫秒数
// 注意：100只是初始估算，需要实车校准
const float MS_PER_CM = 100.0;

// 左转1度所需毫秒数
const float MS_PER_DEG_L = 7.0;

// 右转1度所需毫秒数
const float MS_PER_DEG_R = 7.0;

// 电机方向修正
const bool REVERSE_LEFT = false;
const bool REVERSE_RIGHT = false;

// 测试模式
// 0 = 执行完整路线
// 1 = 前进20厘米
// 2 = 右转90度
// 3 = 左转90度
const int TEST_MODE = 0;


// ====================================
// 4. 声音触发参数
// ====================================

// 越小越灵敏
const int SOUND_THRESHOLD = 80;

// 重新待机前需要连续安静600毫秒
const unsigned long QUIET_TIME_MS = 600;

// 路线结束后暂时忽略声音700毫秒
const unsigned long END_IGNORE_MS = 700;

// 是否允许声音触发
bool soundArmed = false;

// 安静状态开始时间
unsigned long quietStart = 0;

// 上次串口输出时间
unsigned long lastPrint = 0;


// ====================================
// 5. 三条完整路线
// ====================================

struct Step {
  char direction;       // L左转 / R右转
  float angle;          // 转角（度）
  float distance;       // 直行距离（厘米）
  unsigned int pauseMs; // 该段结束后停顿时间
};


// 第一次表演
const Step route1[] = {
  {'R', 54.5, 5.0, 0},
  {'L', 41.6, 5.3, 0},
  {'L', 23.5, 7.6, 0},
  {'L', 29.5, 5.9, 0}
};


// 第二次表演
const Step route2[] = {
  {'L', 61.9, 10.4, 0},
  {'R', 16.5, 9.9, 0},
  {'R', 65.2, 13.7, 800},
  {'L', 152.0, 20.2, 0},
  {'R', 8.6, 17.9, 0}
};


// 第三次表演
const Step route3[] = {
  {'L', 56.7, 7.0, 0},
  {'L', 35.5, 8.8, 0},
  {'L', 21.2, 10.0, 0},
  {'L', 15.2, 12.4, 800},
  {'R', 102.7, 28.4, 0}
};


// ====================================
// 6. 电机控制
// ====================================

void motor(int pin1, int pin2, int speedValue) {

  if (speedValue > 0) {
    analogWrite(pin2, 0);
    analogWrite(pin1, speedValue);
  }
  else if (speedValue < 0) {
    analogWrite(pin1, 0);
    analogWrite(pin2, -speedValue);
  }
  else {
    analogWrite(pin1, 0);
    analogWrite(pin2, 0);
  }
}


void drive(int leftSpeed, int rightSpeed) {

  if (REVERSE_LEFT) {
    leftSpeed = -leftSpeed;
  }

  if (REVERSE_RIGHT) {
    rightSpeed = -rightSpeed;
  }

  motor(L1, L2, leftSpeed);
  motor(R1, R2, rightSpeed);
}


void stopCar() {
  drive(0, 0);
}


// 短暂主动刹车，减少滑行
void brakeCar() {

  digitalWrite(L1, HIGH);
  digitalWrite(L2, HIGH);

  digitalWrite(R1, HIGH);
  digitalWrite(R2, HIGH);

  delay(80);

  stopCar();
}


// ====================================
// 7. 按厘米直行
// ====================================

void forwardCm(float cm) {

  unsigned long runTime =
    (unsigned long)(cm * MS_PER_CM + 0.5);

  drive(DRIVE_PWM, DRIVE_PWM);

  delay(runTime);

  brakeCar();
}


// ====================================
// 8. 按角度转向
// ====================================

void rotateDegrees(char direction, float angle) {

  unsigned long runTime;

  if (direction == 'L') {

    runTime =
      (unsigned long)(angle * MS_PER_DEG_L + 0.5);

    // 左轮后退，右轮前进
    drive(-TURN_PWM, TURN_PWM);

  }
  else {

    runTime =
      (unsigned long)(angle * MS_PER_DEG_R + 0.5);

    // 左轮前进，右轮后退
    drive(TURN_PWM, -TURN_PWM);
  }

  delay(runTime);

  brakeCar();
}


// ====================================
// 9. 读取声音大小
// ====================================

int readSoundLevel() {

  int highest = 0;
  int lowest = 1023;

  unsigned long startTime = millis();

  // 采样40毫秒
  while (millis() - startTime < 40) {

    int value = analogRead(MIC);

    if (value > highest) {
      highest = value;
    }

    if (value < lowest) {
      lowest = value;
    }
  }

  return highest - lowest;
}


// ====================================
// 10. 执行所选路线
// ====================================

void executeRoute() {

  const Step* selectedRoute = route1;
  int stepCount = sizeof(route1) / sizeof(route1[0]);

  if (ROUTE_NUMBER == 2) {

    selectedRoute = route2;
    stepCount = sizeof(route2) / sizeof(route2[0]);

  }
  else if (ROUTE_NUMBER == 3) {

    selectedRoute = route3;
    stepCount = sizeof(route3) / sizeof(route3[0]);
  }

  Serial.print("Start Route ");
  Serial.println(ROUTE_NUMBER);

  // 从这里开始，不读取麦克风

  // 对应动画开始前静止约1秒
  stopCar();
  delay(1000);

  // 校准模式
  if (TEST_MODE == 1) {
    forwardCm(20.0);
  }
  else if (TEST_MODE == 2) {
    rotateDegrees('R', 90.0);
  }
  else if (TEST_MODE == 3) {
    rotateDegrees('L', 90.0);
  }
  else {

    // 完整轨迹
    for (int i = 0; i < stepCount; i++) {

      Serial.print("Step ");
      Serial.println(i + 1);

      // 先原地转向
      rotateDegrees(
        selectedRoute[i].direction,
        selectedRoute[i].angle
      );

      delay(120);

      // 再向前行驶
      forwardCm(selectedRoute[i].distance);

      // 需要额外停顿的路段
      if (selectedRoute[i].pauseMs > 0) {

        delay(selectedRoute[i].pauseMs);
      }
    }
  }

  // 结束，所有电机停止
  stopCar();

  Serial.println("Route Finished");
}


// ====================================
// 11. 开机初始化
// ====================================

void setup() {

  pinMode(L1, OUTPUT);
  pinMode(L2, OUTPUT);

  pinMode(R1, OUTPUT);
  pinMode(R2, OUTPUT);

  pinMode(MIC, INPUT);

  Serial.begin(115200);

  stopCar();

  delay(1500);

  Serial.println("====================");
  Serial.println("Robot Ready");
  Serial.print("Selected Route: ");
  Serial.println(ROUTE_NUMBER);
  Serial.println("Waiting for quiet...");
  Serial.println("====================");
}


// ====================================
// 12. 无限循环：声音启动
// ====================================

void loop() {

  int level = readSoundLevel();

  // 串口显示声音大小
  if (millis() - lastPrint >= 300) {

    Serial.print("Sound = ");
    Serial.println(level);

    lastPrint = millis();
  }


  // ----------------------------------
  // 情况A：还没有进入待机状态
  // ----------------------------------

  if (!soundArmed) {

    // 当前环境低于触发阈值
    if (level < SOUND_THRESHOLD) {

      if (quietStart == 0) {
        quietStart = millis();
      }

      // 已经连续安静足够久
      if (millis() - quietStart >= QUIET_TIME_MS) {

        soundArmed = true;

        Serial.println();
        Serial.println("READY! Waiting for sound...");
        Serial.println();
      }
    }
    else {

      // 环境太吵，重新计算安静时间
      quietStart = 0;
    }

    delay(15);
    return;
  }


  // ----------------------------------
  // 情况B：已经进入待机
  // 检测声音是否达到触发阈值
  // ----------------------------------

  if (level > SOUND_THRESHOLD) {

    Serial.println();
    Serial.println("SOUND DETECTED!");
    Serial.println("Start movement.");
    Serial.println();

    // 立即关闭再次触发资格
    soundArmed = false;
    quietStart = 0;

    // 执行完整动作
    // 运行时不会执行loop中的声音检测
    executeRoute();

    // 路线完成，确保电机停止
    stopCar();

    // 忽略刚结束的机械噪声
    delay(END_IGNORE_MS);

    Serial.println();
    Serial.println("Movement complete.");
    Serial.println("Waiting for quiet...");
    Serial.println();

    // 之后会回到loop开头
    // 等待安静，再次允许声音触发
  }

  delay(15);
}
